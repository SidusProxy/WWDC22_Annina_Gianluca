//
//  InfoView.swift
//  WWDC22_Annina_Gianluca
//
//  Created by Gianluca Annina on 11/04/22.
//

import SwiftUI

struct InfoView: View {
    
    var part1: String = "I’m Gianluca and I have always loved resolving problems. What’s the best way to resolve a problem then? A good idea and a functional code."
    
    var part2: String = "What is one of the worst problem affecting the world, and in particular my city? How to recycle the waste we produce everyday."
    
    var part3: String = "Realizing this I come up with an idea that can help everyone help the world. An instrument that give you an hand when it comes to the recycling act."

    var part4: String = "So let’s use our phones, and a little of Machine Learning, to help us in what is a really difficult but important act."
    
    var part5: String = "Let's recycle together!"
    
    
    var body: some View {
        VStack{
            Image("recsym").resizable().frame(width: 200, height: 200)
            Spacer()
            Text(part1).padding().foregroundColor(.gray).font(.system(size: 30)).multilineTextAlignment(.center)
            
            Text(part2).padding().foregroundColor(.gray).font(.system(size: 30)).multilineTextAlignment(.center)
            Text(part3).padding().foregroundColor(.gray).font(.system(size: 30)).multilineTextAlignment(.center)
            Text(part4).padding().foregroundColor(.gray).font(.system(size: 30)).multilineTextAlignment(.center)
            
            Spacer()
            Text(part5).padding().foregroundColor(.accentColor).font(.system(size: 50)).multilineTextAlignment(.center)
            
            Spacer()
        }
        

    }
}

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
