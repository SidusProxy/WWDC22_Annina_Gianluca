//
//  File.swift
//  WWDC22_Annina_Gianluca
//
//  Created by Gianluca Annina on 11/04/22.
//


var classificationLabel: String = "We are sorry but we weren't able to recognize your object"
var tip=""



import SwiftUI
import CoreML

struct ObjectRecognitionView: View {
    @State private var showSheet: Bool = false
    @State var imageget: UIImage?
    @State private var image: UIImage?
    @State private var currentIndex: Int = 0
    @State private var loading = true
    @State private var showImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var isShowingDetailView = false
    
    let imagePredictor = ImagePredictor()

    
    var body: some View {
        VStack {
            Image(uiImage: imageget!)
                .resizable()
                .frame(width: 400, height: 400)
                .cornerRadius(20).onAppear(perform: {
                    classificationLabel = "We are fetching your data..."
                    tip = "Please wait just a little"
                    Task{
                        loading = true
                        await classifyImage(imageget!)
                        loading = false
                    }
                }).onChange(of: imageget) { newValue in
                    classificationLabel = "We are fetching your data..."
                    tip = "Please wait just a little"
                    Task{
                        loading = true
                        await classifyImage(imageget!)
                        loading = false
                    }
                }
       
            if(!loading){
                VStack{
                    Text(classificationLabel).fontWeight(.bold)
                        .font(.body)
                    
                     Text(tip).multilineTextAlignment(.center)
                         .frame(maxWidth: 300, alignment: .center)
                    
                    
                }.padding(.top, 30)
            }else{
                VStack{
                    Text("We are fetching your data...").fontWeight(.bold)
                        .font(.body)
                    
                     Text("Please wait just a little").multilineTextAlignment(.center)
                         .frame(maxWidth: 300, alignment: .center)
                    
                    
                }.padding(.top, 30)
            }
            
           

            Spacer()
            // The button we will use to classify the image using our model
            Button(action: {self.showSheet.toggle()}) {
                Text("Retake").fontWeight(.bold).padding().padding(.horizontal, 50)
                    .foregroundColor(.white)
                    .background(Color.accentColor)
                    .cornerRadius(10)}
            .actionSheet(isPresented: $showSheet) {
                    ActionSheet(title: Text("Select Photo"), message: Text("Choose"), buttons: [
                        .default(Text("Photo Library")) {
                            self.showImagePicker = true
                            self.sourceType = .photoLibrary

                        },
                        .default(Text("Camera")) {
                            self.showImagePicker = true
                            self.sourceType = .camera
                        },
                        .cancel()
                    ])
            }
           Spacer()
        }.sheet(isPresented: $showImagePicker) {
            ImagePicker(image: self.$imageget, isShown: self.$showImagePicker, isShowingDetailView: self.$isShowingDetailView,  sourceType: self.sourceType)}
    }
    
    
    
    private func classifyImage(_ image: UIImage) async {
        do {
        
            try self.imagePredictor.makePredictions(for: image){ prediction in
                classificationLabel = "We are sorry but we weren't able to recognize your object"
                tip = "Take another photo and try again!"

                guard let prediction = prediction else {
                    classificationLabel = "No predictions. (Check console log.)"
                    return
                }
                if !prediction.isEmpty {
                    classificationLabel = "It's like " + prediction.first!.classification
                    
                    tip = "Check if the label is made of paper or plastic: remove it and trash it in the right bin."
                }else{
                    tip = "Take another photo and try again!"
                    classificationLabel = "We are sorry but we weren't able to recognize your object"
                }
            }
        } catch {
            print("Vision was unable to make a prediction...\n\n\(error.localizedDescription)")
        }
    }

    
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        ObjectRecognitionView()
    }
}









