import SwiftUI

struct HomeView: View {
    
    @State private var showImagePicker: Bool = false
    @State private var showImagePickerCamera = false
    @State private var image: UIImage?
    @State private var isShowingDetailView = false
    @State private var isShowingInfoView = false
    
    
    var body: some View {
        NavigationView{
            
            
            VStack {
                
                Image("buddy").resizable().frame(width: 300, height: 300).cornerRadius(20)
                Text("HelpMeRecycle").font(.system(size: 50)).foregroundColor(Color.accentColor)

                Spacer() 
                Text("You don't know where you should trash your item?").padding().foregroundColor(.black).font(.system(size: 30))
                Text("Just take a simple photo and you'll know it!").padding().foregroundColor(.black).font(.system(size: 30))
                
                Spacer()
                
                HStack{
                    
                    Button(action: {
                        self.showImagePicker = true
                    }) {
                        Text("Library").fontWeight(.bold).font(.system(size: 30)).padding().padding(.horizontal, 100)
                            .foregroundColor(.white)
                            .background(Color.accentColor)
                            .cornerRadius(10)
                        
                    }
                    
                    
                    
                    Button(action: {
                        self.showImagePickerCamera = true
                    }) {
                        
                        Text("Camera").fontWeight(.bold).font(.system(size: 30)).padding().padding(.horizontal, 100)
                            .foregroundColor(.white)
                            .background(Color.accentColor)
                            .cornerRadius(10)
                        
                    }
                }.navigationBarItems(trailing: Button(action: {
                    isShowingInfoView.toggle()
                }, label: {
                    Image(systemName: "info.circle.fill")
                }))
                    .navigationBarItems(leading: Text("HelpMeRecycle").font(.title).foregroundColor(Color.accentColor))
                
                
                
                
                Spacer()
                
                
                NavigationLink(destination: InfoView(), isActive: $isShowingInfoView) { EmptyView() }
                
                NavigationLink(destination: ObjectRecognitionView(imageget: image), isActive: $isShowingDetailView) { EmptyView() }
                
            }
        }.navigationViewStyle(.stack)
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: self.$image, isShown: self.$showImagePicker, isShowingDetailView: self.$isShowingDetailView,  sourceType: UIImagePickerController.SourceType.photoLibrary)
            }
            .sheet(isPresented: $showImagePickerCamera) {
                ImagePicker(image: self.$image, isShown: self.$showImagePickerCamera, isShowingDetailView: self.$isShowingDetailView,  sourceType: UIImagePickerController.SourceType.camera)
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
